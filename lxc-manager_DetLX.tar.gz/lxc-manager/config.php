<?php
/**
 * LXC容器Web管理工具 - 配置文件
 */

// 配置信息
$CONFIG = [
    // 用户配置
    'users' => [
        'admin' => [
            'password' => 'admin123',
            'role' => 'admin',
            'allowed_containers' => ['*']
        ],
        'user1' => [
            'password' => 'user123', 
            'role' => 'user',
            'allowed_containers' => ['web-server', 'db-server', 'user1-']
        ],
        'user2' => [
            'password' => 'user123', 
            'role' => 'user',
            'allowed_containers' => ['app-server', 'user2-']
        ],
        'viewer' => [
            'password' => 'view123', 
            'role' => 'viewer',
            'allowed_containers' => ['web-server']
        ]
    ],
    
    // 权限定义
    'permissions' => [
        'admin' => ['view', 'start', 'stop', 'restart', 'freeze', 'create', 'delete', 'edit', 'backup', 'restore', 'monitor', 'manage_users', 'port_forwarding'],
        'user' => ['view', 'start', 'stop', 'restart', 'freeze', 'backup', 'monitor', 'create_own'],
        'viewer' => ['view', 'monitor']
    ],
    
    // LXC配置
    'lxc_path' => '/var/lib/lxc',
    'backup_path' => '/www/backups/lxc',
    'templates' => [
        'ubuntu' => 'ubuntu:22.04',
        'alpine' => 'alpine:edge',
        'centos' => 'centos:8',
        'debian' => 'debian:11'
    ],
    
    // 资源限制默认值
    'default_limits' => [
        'cpu' => '1',
        'memory' => '512MB',
        'disk' => '10GB'
    ],
    
    // LXC命令配置
    'lxc_command' => [
        'use_sudo' => false,
        'lxc_path' => '/snap/bin/lxc',
        'socket_path' => '/var/snap/lxd/common/lxd/unix.socket'
    ],
    
    // 端口转发配置
    'port_forwarding' => [
        'enabled' => true,
        'iptables_path' => '/sbin/iptables',
        'ip6tables_path' => '/sbin/ip6tables',
        'rules_file' => '/etc/iptables/rules.v4',
        'allowed_ports' => [
            'min' => 1024,
            'max' => 65535
        ]
    ]
];

// 创建必要的目录
if (!is_dir($CONFIG['backup_path'])) {
    mkdir($CONFIG['backup_path'], 0755, true);
}
?>