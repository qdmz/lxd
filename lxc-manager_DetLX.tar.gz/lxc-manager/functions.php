<?php
/**
 * LXC容器Web管理工具 - 工具函数
 * 修复版本：避免函数重复定义
 */

// 全局配置变量
global $CONFIG;

/**
 * 执行系统命令并返回结果
 */
function execute_command($command, $shell = false) {
    $output = [];
    $return_code = 0;
    
    try {
        if ($shell) {
            // 使用shell执行命令
            exec($command, $output, $return_code);
        } else {
            // 将命令分割为数组
            $args = preg_split('/\s+/', $command);
            $command = array_shift($args);
            $escaped_args = array_map('escapeshellarg', $args);
            $full_command = $command . ' ' . implode(' ', $escaped_args);
            exec($full_command, $output, $return_code);
        }
        
        return [
            'success' => $return_code === 0,
            'output' => $output,
            'error' => $return_code !== 0 ? ["Command failed with return code: $return_code"] : [],
            'returncode' => $return_code
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'output' => [],
            'error' => [$e->getMessage()],
            'returncode' => -1
        ];
    }
}

/**
 * 执行LXC命令
 */
function execute_lxc_command($command) {
    global $CONFIG;
    $lxc_config = $CONFIG['lxc_command'];
    $lxc_path = $lxc_config['lxc_path'];
    
    if ($lxc_config['use_sudo']) {
        $full_command = "sudo -n {$lxc_path} {$command}";
    } else {
        $full_command = "{$lxc_path} {$command}";
    }
    
    return execute_command($full_command);
}

/**
 * 执行需要sudo权限的命令
 */
function execute_sudo_command($command) {
    $full_command = "sudo {$command}";
    return execute_command($full_command, true);
}

/**
 * 检查操作权限
 */
function check_permission($action, $container_name = null) {
    if (!isset($_SESSION['user_role'])) {
        return false;
    }
    
    global $CONFIG;
    $role = $_SESSION['user_role'];
    
    // 管理员拥有所有权限
    if ($role === 'admin') {
        return true;
    }
    
    // 检查角色是否存在权限配置
    if (!isset($CONFIG['permissions'][$role])) {
        return false;
    }
    
    // 检查基本权限
    if (!in_array($action, $CONFIG['permissions'][$role])) {
        return false;
    }
    
    // 如果涉及具体容器，检查容器权限
    if ($container_name !== null && !check_container_permission($container_name)) {
        return false;
    }
    
    return true;
}

/**
 * 检查用户对容器的权限
 */
function check_container_permission($container_name) {
    if (session_get('user_role') == 'admin') {
        return true;
    }
    
    $allowed_containers = session_get('allowed_containers', []);
    
    foreach ($allowed_containers as $pattern) {
        // 如果模式以-结尾，表示前缀匹配
        if (substr($pattern, -1) === '-') {
            $prefix = substr($pattern, 0, -1);
            if (strpos($container_name, $prefix) === 0) {
                return true;
            }
        } elseif ($pattern === $container_name || $pattern === '*') {
            return true;
        }
    }
    
    return false;
}

/**
 * 根据用户权限过滤容器列表
 */
function filter_containers_by_permission($containers) {
    return array_filter($containers, function($container) {
        return check_container_permission($container['name']);
    });
}

/**
 * 为普通用户生成容器名称（添加用户名前缀）
 */
function generate_container_name($base_name) {
    if (session_get('user_role') == 'admin') {
        return $base_name;
    }
    
    $username = session_get('username', '');
    
    if (strpos($base_name, "{$username}-") === 0) {
        return $base_name;
    }
    
    return "{$username}-{$base_name}";
}

/**
 * 登录装饰器
 */
function login_required() {
    if (!isset($_SESSION['username'])) {
        header('Location: index.php?action=login');
        exit;
    }
}

/**
 * 获取容器列表
 */
function get_containers() {
    $result = execute_lxc_command("list --format json");
    $containers = [];
    
    if ($result['success'] && !empty($result['output'])) {
        try {
            $json_output = implode('', $result['output']);
            $containers_data = json_decode($json_output, true);
            
            if (json_last_error() === JSON_ERROR_NONE) {
                foreach ($containers_data as $container_data) {
                    $name = $container_data['name'] ?? '未知';
                    $status = strtolower($container_data['status'] ?? 'unknown');
                    $ip = '未知';
                    
                    // 安全地获取IP地址
                    if (isset($container_data['state']) && is_array($container_data['state'])) {
                        $state = $container_data['state'];
                        if (isset($state['network']) && is_array($state['network'])) {
                            foreach ($state['network'] as $interface => $net_info) {
                                if (is_array($net_info) && isset($net_info['addresses']) && is_array($net_info['addresses'])) {
                                    foreach ($net_info['addresses'] as $addr) {
                                        if (is_array($addr) && 
                                            ($addr['family'] ?? '') === 'inet' && 
                                            ($addr['scope'] ?? '') === 'global') {
                                            $ip = $addr['address'] ?? '未知';
                                            break 2;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    $containers[$name] = [
                        'name' => $name,
                        'status' => $status,
                        'ip' => $ip,
                        'cpu_usage' => '0%',
                        'memory_usage' => '0MB/0MB',
                        'disk_usage' => '0GB/0GB',
                        'processes' => '0',
                        'owner' => '未知'
                    ];
                    
                    // 尝试识别所有者
                    if (strpos($name, '-') !== false) {
                        $prefix = explode('-', $name)[0];
                        $containers[$name]['owner'] = $prefix;
                    }
                }
            }
        } catch (Exception $e) {
            error_log("JSON解析错误: " . $e->getMessage());
        }
    }
    
    // 如果JSON解析失败，尝试解析文本格式
    if (empty($containers) && $result['success']) {
        foreach ($result['output'] as $line) {
            if (strpos($line, 'NAME') !== false || strpos($line, '---') !== false || trim($line) === '') {
                continue;
            }
            
            $parts = preg_split('/\s+/', $line);
            if (count($parts) >= 2) {
                $name = $parts[0];
                $status = strtolower($parts[1]);
                $ip = '未知';
                
                // 尝试从后续部分提取IP
                for ($i = 2; $i < count($parts); $i++) {
                    if (strpos($parts[$i], '.') !== false && substr_count($parts[$i], '.') === 3) {
                        $ip_parts = explode('.', $parts[$i]);
                        if (count($ip_parts) === 4 && ctype_digit(implode('', $ip_parts))) {
                            $ip = $parts[$i];
                            break;
                        }
                    }
                }
                
                $containers[$name] = [
                    'name' => $name,
                    'status' => $status,
                    'ip' => $ip,
                    'cpu_usage' => '0%',
                    'memory_usage' => '0MB/0MB',
                    'disk_usage' => '0GB/0GB',
                    'processes' => '0',
                    'owner' => '未知'
                ];
                
                if (strpos($name, '-') !== false) {
                    $prefix = explode('-', $name)[0];
                    $containers[$name]['owner'] = $prefix;
                }
            }
        }
    }
    
    return filter_containers_by_permission($containers);
}

/**
 * 获取备份列表
 */
function get_backups() {
    global $CONFIG;
    $backup_dir = $CONFIG['backup_path'];
    $backups = [];
    
    if (!is_dir($backup_dir)) {
        return $backups;
    }
    
    try {
        $files = scandir($backup_dir);
        foreach ($files as $file) {
            if (strpos($file, '.tar.gz') !== false && strpos($file, '_backup_') !== false) {
                $parts = explode('_backup_', $file);
                if (count($parts) === 2) {
                    $container_name = $parts[0];
                    $timestamp = str_replace('.tar.gz', '', $parts[1]);
                    
                    if (check_container_permission($container_name)) {
                        $file_path = $backup_dir . '/' . $file;
                        $file_size = file_exists($file_path) ? filesize($file_path) : 0;
                        
                        $backups[] = [
                            'file' => $file,
                            'container' => $container_name,
                            'date' => str_replace('_', ' ', $timestamp),
                            'path' => $file_path,
                            'size' => $file_size
                        ];
                    }
                }
            }
        }
    } catch (Exception $e) {
        error_log("读取备份错误: " . $e->getMessage());
    }
    
    return $backups;
}

/**
 * 获取端口转发规则列表
 */
function get_port_forwarding_rules() {
    global $CONFIG;
    $rules = [];
    
    if (!$CONFIG['port_forwarding']['enabled']) {
        return $rules;
    }
    
    try {
        // 获取NAT表的PREROUTING链规则
        $result = execute_sudo_command("{$CONFIG['port_forwarding']['iptables_path']} -t nat -L PREROUTING -n --line-numbers");
        
        if ($result['success']) {
            foreach ($result['output'] as $line) {
                // 查找DNAT规则
                if (strpos($line, 'DNAT') !== false && (strpos($line, 'dpt:') !== false || strpos($line, 'dport ') !== false)) {
                    $parts = preg_split('/\s+/', trim($line));
                    if (count($parts) >= 11) {
                        $rule_num = $parts[0];
                        
                        // 确定协议
                        $protocol = 'tcp';
                        if (strpos($line, 'udp') !== false) {
                            $protocol = 'udp';
                        }
                        
                        // 提取目标端口
                        $external_port = '';
                        if (preg_match('/dpt:(\d+)/', $line, $matches)) {
                            $external_port = $matches[1];
                        } elseif (preg_match('/dport (\d+)/', $line, $matches)) {
                            $external_port = $matches[1];
                        }
                        
                        if (empty($external_port)) continue;
                        
                        // 提取目标地址
                        $container_ip = '';
                        $internal_port = '';
                        if (preg_match('/to:([\d.]+):(\d+)/', $line, $matches)) {
                            $container_ip = $matches[1];
                            $internal_port = $matches[2];
                        } elseif (preg_match('/to-destination ([\d.]+):(\d+)/', $line, $matches)) {
                            $container_ip = $matches[1];
                            $internal_port = $matches[2];
                        }
                        
                        if (empty($container_ip) || empty($internal_port)) continue;
                        
                        // 获取容器名称
                        $container_name = get_container_by_ip($container_ip);
                        
                        $rules[] = [
                            'rule_num' => $rule_num,
                            'protocol' => $protocol,
                            'external_port' => $external_port,
                            'container_ip' => $container_ip,
                            'container_name' => $container_name,
                            'internal_port' => $internal_port,
                            'description' => $protocol . " " . $external_port . " → " . $container_name . ":" . $internal_port
                        ];
                    }
                }
            }
        }
    } catch (Exception $e) {
        error_log("获取端口转发规则错误: " . $e->getMessage());
    }
    
    return $rules;
}

/**
 * 根据IP地址获取容器名称
 */
function get_container_by_ip($ip) {
    $containers = get_containers();
    foreach ($containers as $name => $container) {
        if ($container['ip'] === $ip) {
            return $name;
        }
    }
    return '未知';
}



/**
 * 添加端口转发规则
 */
function add_port_forwarding_rule($protocol, $external_port, $container_name, $internal_port, $description = "") {
    global $CONFIG;
    
    if (!$CONFIG['port_forwarding']['enabled']) {
        return ['success' => false, 'message' => '端口转发功能已禁用'];
    }
    
    // 验证端口号
    try {
        $ext_port = intval($external_port);
        $int_port = intval($internal_port);
        
        $min_port = $CONFIG['port_forwarding']['allowed_ports']['min'];
        $max_port = $CONFIG['port_forwarding']['allowed_ports']['max'];
        
        if ($ext_port < $min_port || $ext_port > $max_port || $int_port < 1 || $int_port > 65535) {
            return ['success' => false, 'message' => "端口号必须在".$min_port."-65535范围内"];
        }
    } catch (Exception $e) {
        return ['success' => false, 'message' => '端口号必须是数字'];
    }
    
    // 验证协议
    if (!in_array($protocol, ['tcp', 'udp'])) {
        return ['success' => false, 'message' => '协议必须是tcp或udp'];
    }
    
    // 获取容器IP
    $containers = get_containers();
    if (!isset($containers[$container_name])) {
        return ['success' => false, 'message' => '容器不存在'];
    }
    
    $container_ip = $containers[$container_name]['ip'];
    if ($container_ip === '未知') {
        return ['success' => false, 'message' => '无法获取容器IP地址'];
    }
    
    // 检查端口是否已被占用
    $rules = get_port_forwarding_rules();
    foreach ($rules as $rule) {
        if ($rule['protocol'] === $protocol && $rule['external_port'] == $external_port) {
            return ['success' => false, 'message' => $protocol."端口".$external_port."已被占用"];
        }
    }
    
    // 添加端口转发规则
    try {
        // 添加PREROUTING规则
        $cmd = "{$CONFIG['port_forwarding']['iptables_path']} -t nat -A PREROUTING " .
               "-p {$protocol} --dport {$external_port} " .
               "-j DNAT --to-destination {$container_ip}:{$internal_port}";
        
        $result = execute_sudo_command($cmd);
        
        if (!$result['success']) {
            $error_msg = !empty($result['error']) ? implode(' ', $result['error']) : '未知错误';
            return ['success' => false, 'message' => "添加规则失败: ".$error_msg];
        }
        
        // 保存规则（如果配置了规则文件）
        if (!empty($CONFIG['port_forwarding']['rules_file'])) {
            $save_result = execute_sudo_command("{$CONFIG['port_forwarding']['iptables_path']}-save > {$CONFIG['port_forwarding']['rules_file']}");
            if (!$save_result['success']) {
                return ['success' => true, 'message' => '规则已添加但保存失败，重启后可能失效'];
            }
        }
        
        return ['success' => true, 'message' => '端口转发规则添加成功'];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => "添加规则时出错: ".$e->getMessage()];
    }
}

/**
 * 删除端口转发规则
 */
function delete_port_forwarding_rule($rule_num, $protocol) {
    global $CONFIG;
    
    if (!$CONFIG['port_forwarding']['enabled']) {
        return ['success' => false, 'message' => '端口转发功能已禁用'];
    }
    
    try {
        // 删除PREROUTING规则
        $cmd = "{$CONFIG['port_forwarding']['iptables_path']} -t nat -D PREROUTING {$rule_num}";
        $result = execute_sudo_command($cmd);
        
        if (!$result['success']) {
            $error_msg = !empty($result['error']) ? implode(' ', $result['error']) : '未知错误';
            return ['success' => false, 'message' => "删除规则失败: " . $error_msg];
        }
        
        // 保存规则（如果配置了规则文件）
        if (!empty($CONFIG['port_forwarding']['rules_file'])) {
            $save_result = execute_sudo_command("{$CONFIG['port_forwarding']['iptables_path']}-save > {$CONFIG['port_forwarding']['rules_file']}");
            if (!$save_result['success']) {
                return ['success' => true, 'message' => '规则已删除但保存失败，重启后可能恢复'];
            }
        }
        
        return ['success' => true, 'message' => '端口转发规则删除成功'];
        
    } catch (Exception $e) {
        return ['success' => false, 'message' => "删除规则时出错: " . $e->getMessage()];
    }
}

/**
 * 添加消息闪现
 */
function flash_message($message, $type = 'info') {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }
    $_SESSION['flash_messages'][] = ['message' => $message, 'type' => $type];
}

/**
 * 获取消息闪现
 */
function get_flash_messages() {
    if (isset($_SESSION['flash_messages'])) {
        $messages = $_SESSION['flash_messages'];
        unset($_SESSION['flash_messages']);
        return $messages;
    }
    return [];
}

/**
 * 从会话中安全获取值
 */
function session_get($key, $default = null) {
    return isset($_SESSION[$key]) ? $_SESSION[$key] : $default;
}

/**
 * 安全的字符串分割函数
 */
function shlex_split($command) {
    if (function_exists('shlex_split')) {
        return shlex_split($command);
    }
    
    // 简单的替代实现
    preg_match_all('/([^\s\\\']\S*|\'.+?\'|".+?")\s*/', $command, $matches);
    return $matches[1] ?: [];
}

/**
 * 安全的子进程运行函数
 */
function subprocess_run($command, $shell = false, $capture_output = false, $text = false) {
    if ($shell) {
        $output = shell_exec($command);
        $returncode = $output === null ? 1 : 0;
    } else {
        $returncode = 0;
        $output = [];
        exec($command, $output, $returncode);
    }
    
    return [
        'returncode' => $returncode,
        'stdout' => $output,
        'stderr' => ''
    ];
}

/**
 * 获取系统信息
 */
function get_system_info() {
    $info = [
        'hostname' => '未知',
        'uptime' => '未知',
        'load_average' => '未知',
        'memory_usage' => [],
        'disk_usage' => []
    ];
    
    try {
        // 获取主机名
        $hostname_result = execute_command('hostname');
        if ($hostname_result['success'] && !empty($hostname_result['output'])) {
            $info['hostname'] = $hostname_result['output'][0];
        }
        
        // 获取运行时间
        $uptime_result = execute_command('uptime -p');
        if ($uptime_result['success'] && !empty($uptime_result['output'])) {
            $info['uptime'] = $uptime_result['output'][0];
        }
        
        // 获取负载平均值
        $loadavg_result = execute_command('cat /proc/loadavg');
        if ($loadavg_result['success'] && !empty($loadavg_result['output'])) {
            $info['load_average'] = $loadavg_result['output'][0];
        }
        
        // 获取内存使用情况
        $memory_result = execute_command('free -h');
        if ($memory_result['success']) {
            $info['memory_usage'] = $memory_result['output'];
        }
        
        // 获取磁盘使用情况
        $disk_result = execute_command('df -h /');
        if ($disk_result['success']) {
            $info['disk_usage'] = $disk_result['output'];
        }
    } catch (Exception $e) {
        error_log("获取系统信息错误: " . $e->getMessage());
    }
    
    return $info;
}

/**
 * 检查服务状态
 */
function check_service_status($service_name) {
    $result = execute_sudo_command("systemctl is-active {$service_name}");
    return [
        'success' => $result['success'],
        'active' => $result['success'] && !empty($result['output']) && $result['output'][0] === 'active',
        'output' => $result['output']
    ];
}

/**
 * 获取LXD服务状态
 */
function get_lxd_service_status() {
    return check_service_status('snap.lxd.daemon');
}

/**
 * 获取存储池信息
 */
function get_storage_pools() {
    $result = execute_lxc_command("storage list --format json");
    $pools = [];
    
    if ($result['success'] && !empty($result['output'])) {
        try {
            $json_output = implode('', $result['output']);
            $pools = json_decode($json_output, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $pools = [];
            }
        } catch (Exception $e) {
            error_log("解析存储池信息错误: " . $e->getMessage());
        }
    }
    
    return $pools;
}

/**
 * 获取网络信息
 */
function get_networks() {
    $result = execute_lxc_command("network list --format json");
    $networks = [];
    
    if ($result['success'] && !empty($result['output'])) {
        try {
            $json_output = implode('', $result['output']);
            $networks = json_decode($json_output, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $networks = [];
            }
        } catch (Exception $e) {
            error_log("解析网络信息错误: " . $e->getMessage());
        }
    }
    
    return $networks;
}

/**
 * 获取配置文件信息
 */
function get_profiles() {
    $result = execute_lxc_command("profile list --format json");
    $profiles = [];
    
    if ($result['success'] && !empty($result['output'])) {
        try {
            $json_output = implode('', $result['output']);
            $profiles = json_decode($json_output, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $profiles = [];
            }
        } catch (Exception $e) {
            error_log("解析配置文件信息错误: " . $e->getMessage());
        }
    }
    
    return $profiles;
}

/**
 * 获取容器统计信息
 */
function get_container_stats() {
    $containers = get_containers();
    $stats = [
        'total' => 0,
        'running' => 0,
        'stopped' => 0,
        'frozen' => 0,
        'error' => 0
    ];
    
    $stats['total'] = count($containers);
    
    foreach ($containers as $container) {
        $status = $container['status'];
        if ($status == 'running') {
            $stats['running']++;
        } elseif ($status == 'stopped') {
            $stats['stopped']++;
        } elseif ($status == 'frozen') {
            $stats['frozen']++;
        } elseif ($status == 'error') {
            $stats['error']++;
        }
    }
    
    return $stats;
}

/**
 * 检查备份目录状态
 */
function get_backup_status() {
    global $CONFIG;
    $backup_dir = $CONFIG['backup_path'];
    $status = [
        'exists' => false,
        'writable' => false,
        'size' => 0
    ];
    
    $status['exists'] = is_dir($backup_dir);
    
    if ($status['exists']) {
        $status['writable'] = is_writable($backup_dir);
        
        try {
            $total_size = 0;
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($backup_dir, RecursiveDirectoryIterator::SKIP_DOTS)
            );
            
            foreach ($files as $file) {
                if ($file->isFile()) {
                    $total_size += $file->getSize();
                }
            }
            
            $status['size'] = $total_size;
        } catch (Exception $e) {
            error_log("计算备份大小错误: " . $e->getMessage());
        }
    }
    
    return $status;
}

/**
 * 获取服务状态
 */
function get_services_status() {
    $services = [
        'lxd' => get_lxd_service_status(),
        'apparmor' => check_service_status('apparmor'),
        'ufw' => check_service_status('ufw'),
        'iptables' => check_service_status('iptables')
    ];
    
    return $services;
}

/**
 * 验证容器名称格式
 */
function validate_container_name($name) {
    return preg_match('/^[a-z0-9\-_]+$/', $name) === 1;
}

/**
 * 格式化文件大小
 */
function format_file_size($bytes) {
    if ($bytes == 0) {
        return '0 B';
    }
    
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes, 1024));
    $size = round($bytes / pow(1024, $i), 2);
    
    return $size . ' ' . $units[$i];
}

/**
 * 安全重定向
 */
function safe_redirect($url) {
    if (!headers_sent()) {
        header('Location: ' . $url);
        exit;
    } else {
        echo '<script>window.location.href="' . $url . '";</script>';
        exit;
    }
}

/**
 * 记录操作日志
 */
function log_action($action, $details = '') {
    $username = session_get('username', '未知用户');
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? '未知IP';
    
    $log_message = "[{$timestamp}] {$username}@{$ip} - {$action}";
    if (!empty($details)) {
        $log_message .= " - {$details}";
    }
    
    error_log("LXC管理操作: {$log_message}");
}

// 确保必要的目录存在
function ensure_directories() {
    global $CONFIG;
    
    if (!is_dir($CONFIG['backup_path'])) {
        mkdir($CONFIG['backup_path'], 0755, true);
    }
}
?>