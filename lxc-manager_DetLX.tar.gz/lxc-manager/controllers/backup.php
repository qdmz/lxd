<?php
require_once './config.php';
require_once './functions.php';

if (!check_permission('backup')) {
    flash_message('没有权限访问备份管理页面', 'error');
    header('Location: index.php?action=containers');
    exit;
}

$title = '备份管理 - LXC容器管理';
$backups = get_backups();
$containers = get_containers();

ob_start();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>备份管理</h2>
    <a href="index.php?action=containers" class="btn btn-outline-primary">
        <i class="fas fa-arrow-left me-1"></i>返回容器列表
    </a>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">创建备份</h5>
            </div>
            <div class="card-body">
                <form method="post" action="index.php?action=backup_action">
                    <input type="hidden" name="action" value="create">
                    <div class="mb-3">
                        <label for="container_name" class="form-label">选择容器</label>
                        <select class="form-control" id="container_name" name="container_name" required>
                            <option value="">选择容器...</option>
                            <?php foreach ($containers as $name => $container): ?>
                                <?php if ($container['status'] == 'running'): ?>
                                    <option value="<?php echo htmlspecialchars($name); ?>">
                                        <?php echo htmlspecialchars($name); ?> (<?php echo htmlspecialchars($container['ip']); ?>)
                                    </option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success w-100">
                        <i class="fas fa-plus-circle me-1"></i>创建备份
                    </button>
                </form>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">恢复备份</h5>
            </div>
            <div class="card-body">
                <form method="post" action="index.php?action=backup_action">
                    <input type="hidden" name="action" value="restore">
                    <div class="mb-3">
                        <label for="backup_file" class="form-label">选择备份文件</label>
                        <select class="form-control" id="backup_file" name="backup_file" required>
                            <option value="">选择备份...</option>
                            <?php foreach ($backups as $backup): ?>
                                <option value="<?php echo htmlspecialchars($backup['file']); ?>">
                                    <?php echo htmlspecialchars($backup['container']); ?> - <?php echo htmlspecialchars($backup['date']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="new_name" class="form-label">新容器名称</label>
                        <input type="text" class="form-control" id="new_name" name="new_name" 
                               pattern="[a-zA-Z0-9\-_]+" title="只能包含字母、数字、横线和下划线" required>
                        <div class="form-text">
                            <?php if ($_SESSION['user_role'] == 'admin'): ?>
                                请输入新容器名称
                            <?php else: ?>
                                注意：容器名称将自动添加 "<?php echo $_SESSION['username']; ?>-" 前缀
                            <?php endif; ?>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-undo me-1"></i>恢复备份
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">备份列表 (<?php echo count($backups); ?> 个)</h5>
            </div>
            <div class="card-body">
                <?php if (!empty($backups)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>备份文件</th>
                                    <th>容器</th>
                                    <th>备份时间</th>
                                    <th>文件大小</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($backups as $backup): ?>
                                    <tr>
                                        <td>
                                            <code class="bg-light p-1 rounded"><?php echo htmlspecialchars($backup['file']); ?></code>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($backup['container']); ?>
                                            <?php if (strpos($backup['container'], '-') !== false): ?>
                                                <span class="owner-tag"><?php echo explode('-', $backup['container'])[0]; ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo htmlspecialchars($backup['date']); ?></td>
                                        <td>
                                            <span class="badge bg-secondary">
                                                <?php echo $backup['size'] > 0 ? number_format($backup['size'] / 1024 / 1024, 2) . ' MB' : '未知'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="btn-group btn-group-sm">
                                                <a href="index.php?action=backup_action&download=<?php echo urlencode($backup['file']); ?>" 
                                                   class="btn btn-success btn-sm" title="下载备份">
                                                    <i class="fas fa-download"></i>
                                                </a>
                                                <form method="post" action="index.php?action=backup_action" class="d-inline">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="backup_file" value="<?php echo htmlspecialchars($backup['file']); ?>">
                                                    <button type="submit" class="btn btn-danger btn-sm" 
                                                            onclick="return confirm('确定删除此备份吗？')" title="删除备份">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-archive fa-3x text-muted mb-3"></i>
                        <p class="text-muted">暂无备份文件</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="card-title mb-0">使用说明</h5>
    </div>
    <div class="card-body">
        <h6>备份功能说明：</h6>
        <ul>
            <li><strong>创建备份</strong>：为运行中的容器创建完整备份</li>
            <li><strong>恢复备份</strong>：从备份文件恢复容器到新容器</li>
            <li><strong>下载备份</strong>：将备份文件下载到本地保存</li>
            <li><strong>删除备份</strong>：删除不再需要的备份文件以释放空间</li>
        </ul>
        
        <h6>注意事项：</h6>
        <ul>
            <li>只有运行中的容器才能创建备份</li>
            <li>恢复备份会创建新的容器，不会影响原容器</li>
            <li>备份文件保存在服务器上，定期清理不必要的备份</li>
            <li>备份文件包含容器完整配置和数据</li>
        </ul>
    </div>
</div>
<?php
$content = ob_get_clean();
include 'templates/base.php';
?>