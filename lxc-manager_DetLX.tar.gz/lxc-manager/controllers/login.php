<?php
require_once './config.php';
require_once './functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    global $CONFIG;
    
    if (isset($CONFIG['users'][$username]) && $CONFIG['users'][$username]['password'] === $password) {
        // 登录成功
        $_SESSION['username'] = $username;
        $_SESSION['user_role'] = $CONFIG['users'][$username]['role'];
        $_SESSION['allowed_containers'] = $CONFIG['users'][$username]['allowed_containers'];
        $_SESSION['authenticated'] = true;
        
        flash_message('登录成功！', 'success');
        header('Location: index.php?action=containers');
        exit;
    } else {
        flash_message('用户名或密码错误！', 'error');
    }
}

$title = '登录 - LXC容器管理';
ob_start();
?>
<div class="row justify-content-center">
    <div class="col-md-6 col-lg-4">
        <div class="card">
            <div class="card-header text-center">
                <h4 class="card-title mb-0">LXC容器管理登录</h4>
            </div>
            <div class="card-body">
                <form method="post">
                    <div class="mb-3">
                        <label for="username" class="form-label">用户名</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">密码</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">登录</button>
                </form>
                
                <div class="mt-4">
                    <h6>测试账户：</h6>
                    <ul class="list-unstyled">
                        <li><strong>管理员</strong>：admin / admin123</li>
                        <li><strong>普通用户</strong>：user1 / user123</li>
                        <li><strong>查看者</strong>：viewer / view123</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
include 'templates/base.php';
?>