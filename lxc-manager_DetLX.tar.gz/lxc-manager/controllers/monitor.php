<?php
require_once './config.php';
require_once './functions.php';

if (!check_permission('monitor')) {
    flash_message('没有权限访问资源监控页面', 'error');
    header('Location: index.php?action=containers');
    exit;
}

$title = '资源监控 - LXC容器管理';
$containers = get_containers();

ob_start();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>资源监控</h2>
    <a href="index.php?action=containers" class="btn btn-outline-primary">
        <i class="fas fa-arrow-left me-1"></i>返回容器列表
    </a>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">资源使用情况</h5>
    </div>
    <div class="card-body">
        <?php if (!empty($containers)): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>容器名称</th>
                            <th>状态</th>
                            <th>IP地址</th>
                            <th>CPU使用率</th>
                            <th>内存使用</th>
                            <th>磁盘使用</th>
                            <th>进程数</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($containers as $container): ?>
                            <tr>
                                <td>
                                    <?php echo htmlspecialchars($container['name']); ?>
                                    <?php if ($container['owner'] !== '未知'): ?>
                                        <span class="owner-tag"><?php echo htmlspecialchars($container['owner']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status status-<?php echo $container['status']; ?>">
                                        <?php 
                                        switch ($container['status']) {
                                            case 'running': echo '运行中'; break;
                                            case 'stopped': echo '已停止'; break;
                                            case 'frozen': echo '已冻结'; break;
                                            default: echo htmlspecialchars($container['status']);
                                        }
                                        ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($container['ip']); ?></td>
                                <td>
                                    <div class="resource-bar">
                                        <div class="resource-fill cpu-fill" style="width: <?php echo intval(str_replace('%', '', $container['cpu_usage'])); ?>%"></div>
                                    </div>
                                    <?php echo htmlspecialchars($container['cpu_usage']); ?>
                                </td>
                                <td>
                                    <div class="resource-bar">
                                        <div class="resource-fill memory-fill" style="width: <?php 
                                            $memory_parts = explode('(', $container['memory_usage']);
                                            echo isset($memory_parts[1]) ? intval(str_replace('%', '', $memory_parts[1])) : 0;
                                        ?>%"></div>
                                    </div>
                                    <?php echo htmlspecialchars($container['memory_usage']); ?>
                                </td>
                                <td>
                                    <div class="resource-bar">
                                        <div class="resource-fill disk-fill" style="width: <?php 
                                            $disk_parts = explode('/', $container['disk_usage']);
                                            if (count($disk_parts) === 2) {
                                                $used = floatval($disk_parts[0]);
                                                $total = floatval($disk_parts[1]);
                                                echo $total > 0 ? ($used / $total) * 100 : 0;
                                            } else {
                                                echo 0;
                                            }
                                        ?>%"></div>
                                    </div>
                                    <?php echo htmlspecialchars($container['disk_usage']); ?>
                                </td>
                                <td><?php echo htmlspecialchars($container['processes']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-4">
                <i class="fas fa-chart-bar fa-3x text-muted mb-3"></i>
                <p class="text-muted">没有可监控的容器</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php
$content = ob_get_clean();
include 'templates/base.php';
?>