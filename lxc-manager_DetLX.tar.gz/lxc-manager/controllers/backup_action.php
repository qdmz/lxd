<?php
require_once './config.php';
require_once './functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['download'])) {
    // 下载备份文件
    if (!check_permission('backup')) {
        flash_message('没有权限下载备份', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    $filename = $_GET['download'];
    $file_path = $CONFIG['backup_path'] . '/' . $filename;
    
    if (!file_exists($file_path)) {
        flash_message('备份文件不存在', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    // 检查用户是否有权限下载此备份
    $container_name = explode('_backup_', $filename)[0];
    if (!check_container_permission($container_name)) {
        flash_message('没有权限下载此备份', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file_path));
    readfile($file_path);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    flash_message('非法请求', 'error');
    header('Location: index.php?action=backup');
    exit;
}

$action = $_POST['action'] ?? '';

switch ($action) {
    case 'create':
        create_backup();
        break;
    case 'restore':
        restore_backup();
        break;
    case 'delete':
        delete_backup();
        break;
    default:
        flash_message('不支持的操作', 'error');
        header('Location: index.php?action=backup');
        exit;
}

function create_backup() {
    global $CONFIG;
    
    if (!check_permission('backup')) {
        flash_message('没有权限创建备份', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    $container_name = $_POST['container_name'] ?? '';
    
    if (empty($container_name)) {
        flash_message('参数错误', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    if (!check_permission('backup', $container_name)) {
        flash_message('没有权限备份此容器', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    // 创建备份目录
    $backup_dir = $CONFIG['backup_path'];
    if (!is_dir($backup_dir)) {
        mkdir($backup_dir, 0755, true);
    }
    
    $timestamp = date('Y-m-d_H-i-s');
    $backup_name = "{$container_name}_backup_{timestamp}";
    
    // 创建快照
    $result = execute_lxc_command("publish {$container_name} --alias {$backup_name}");
    
    if (!$result['success']) {
        $error_msg = !empty($result['error']) ? implode(' ', $result['error']) : '未知错误';
        flash_message("备份创建失败: {$error_msg}", 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    // 导出备份
    $export_file = "{$backup_dir}/{$backup_name}.tar.gz";
    $result = execute_lxc_command("image export {$backup_name} {$export_file}");
    
    // 删除临时镜像
    execute_lxc_command("image delete {$backup_name}");
    
    if ($result['success']) {
        flash_message('备份创建成功', 'success');
    } else {
        flash_message('备份导出失败', 'error');
    }
    
    header('Location: index.php?action=backup');
    exit;
}

function restore_backup() {
    if (!check_permission('create_own')) {
        flash_message('没有权限恢复备份', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    $backup_file = $_POST['backup_file'] ?? '';
    $new_name = $_POST['new_name'] ?? '';
    
    if (empty($backup_file) || empty($new_name)) {
        flash_message('参数错误', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    // 生成最终的容器名称
    $final_name = generate_container_name($new_name);
    
    // 导入镜像
    $result = execute_lxc_command("image import {$backup_file} temp_restore");
    
    if (!$result['success']) {
        flash_message('备份导入失败', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    // 从镜像启动容器
    $result = execute_lxc_command("launch temp_restore {$final_name}");
    
    // 删除临时镜像
    execute_lxc_command("image delete temp_restore");
    
    if ($result['success']) {
        flash_message("备份恢复成功，容器名: {$final_name}", 'success');
    } else {
        flash_message('恢复失败', 'error');
    }
    
    header('Location: index.php?action=containers');
    exit;
}

function delete_backup() {
    global $CONFIG;
    
    if (!check_permission('backup')) {
        flash_message('没有权限删除备份', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    $backup_file = $_POST['backup_file'] ?? '';
    
    if (empty($backup_file)) {
        flash_message('参数错误', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    $file_path = $CONFIG['backup_path'] . '/' . $backup_file;
    
    // 检查用户是否有权限删除此备份
    $container_name = explode('_backup_', $backup_file)[0];
    if (!check_container_permission($container_name)) {
        flash_message('没有权限删除此备份', 'error');
        header('Location: index.php?action=backup');
        exit;
    }
    
    try {
        if (file_exists($file_path)) {
            unlink($file_path);
            flash_message('备份删除成功', 'success');
        } else {
            flash_message('备份文件不存在', 'error');
        }
    } catch (Exception $e) {
        flash_message("删除失败: {$e->getMessage()}", 'error');
    }
    
    header('Location: index.php?action=backup');
    exit;
}
?>