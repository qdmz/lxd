<?php
require_once './config.php';
require_once './functions.php';

$title = '容器管理 - LXC容器管理';
$containers = get_containers();

ob_start();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>容器管理</h2>
    <div>
        <?php if (check_permission('create_own')): ?>
            <a href="index.php?action=create" class="btn btn-success me-2">
                <i class="fas fa-plus-circle me-1"></i>创建容器
            </a>
        <?php endif; ?>
        <a href="index.php?action=monitor" class="btn btn-outline-primary">
            <i class="fas fa-chart-bar me-1"></i>资源监控
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">容器列表 (<?php echo count($containers); ?> 个)</h5>
    </div>
    <div class="card-body">
        <?php if (!empty($containers)): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>容器名称</th>
                            <th>状态</th>
                            <th>IP地址</th>
                            <th>CPU使用率</th>
                            <th>内存使用</th>
                            <th>磁盘使用</th>
                            <th>进程数</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($containers as $container): ?>
                            <tr>
                                <td>
                                    <?php echo htmlspecialchars($container['name']); ?>
                                    <?php if ($container['owner'] !== '未知'): ?>
                                        <span class="owner-tag"><?php echo htmlspecialchars($container['owner']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="status status-<?php echo $container['status']; ?>">
                                        <?php 
                                        switch ($container['status']) {
                                            case 'running': echo '运行中'; break;
                                            case 'stopped': echo '已停止'; break;
                                            case 'frozen': echo '已冻结'; break;
                                            default: echo htmlspecialchars($container['status']);
                                        }
                                        ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($container['ip']); ?></td>
                                <td>
                                    <div class="resource-bar">
                                        <div class="resource-fill cpu-fill" style="width: <?php echo intval(str_replace('%', '', $container['cpu_usage'])); ?>%"></div>
                                    </div>
                                    <?php echo htmlspecialchars($container['cpu_usage']); ?>
                                </td>
                                <td>
                                    <div class="resource-bar">
                                        <div class="resource-fill memory-fill" style="width: <?php 
                                            $memory_parts = explode('(', $container['memory_usage']);
                                            echo isset($memory_parts[1]) ? intval(str_replace('%', '', $memory_parts[1])) : 0;
                                        ?>%"></div>
                                    </div>
                                    <?php echo htmlspecialchars($container['memory_usage']); ?>
                                </td>
                                <td><?php echo htmlspecialchars($container['disk_usage']); ?></td>
                                <td><?php echo htmlspecialchars($container['processes']); ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <form method="post" action="index.php?action=container_action" class="d-inline">
                                            <input type="hidden" name="container_name" value="<?php echo htmlspecialchars($container['name']); ?>">
                                            
                                            <?php if ($container['status'] === 'stopped' && check_permission('start', $container['name'])): ?>
                                                <input type="hidden" name="action" value="start">
                                                <button type="submit" class="btn btn-success btn-sm" title="启动">
                                                    <i class="fas fa-play"></i>
                                                </button>
                                            <?php endif; ?>
                                            
                                            <?php if ($container['status'] === 'running' && check_permission('stop', $container['name'])): ?>
                                                <input type="hidden" name="action" value="stop">
                                                <button type="submit" class="btn btn-warning btn-sm" title="停止">
                                                    <i class="fas fa-stop"></i>
                                                </button>
                                            <?php endif; ?>
                                            
                                            <?php if ($container['status'] === 'running' && check_permission('restart', $container['name'])): ?>
                                                <input type="hidden" name="action" value="restart">
                                                <button type="submit" class="btn btn-info btn-sm" title="重启">
                                                    <i class="fas fa-redo"></i>
                                                </button>
                                            <?php endif; ?>
                                            
                                            <?php if (check_permission('delete', $container['name'])): ?>
                                                <input type="hidden" name="action" value="delete">
                                                <button type="submit" class="btn btn-danger btn-sm" title="删除" 
                                                        onclick="return confirm('确定删除容器 <?php echo htmlspecialchars($container['name']); ?> 吗？此操作不可逆！')">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            <?php endif; ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="text-center py-4">
                <i class="fas fa-server fa-3x text-muted mb-3"></i>
                <p class="text-muted">没有可管理的容器</p>
                <?php if (check_permission('create_own')): ?>
                    <a href="index.php?action=create" class="btn btn-primary">
                        <i class="fas fa-plus-circle me-1"></i>创建第一个容器
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php
$content = ob_get_clean();
include 'templates/base.php';
?>