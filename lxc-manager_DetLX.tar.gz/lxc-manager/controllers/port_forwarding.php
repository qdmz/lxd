<?php
require_once './config.php';
require_once './functions.php';

if (!check_permission('port_forwarding')) {
    flash_message('没有权限访问端口转发管理页面', 'error');
    header('Location: index.php?action=containers');
    exit;
}

$title = '端口转发管理 - LXC容器管理';
$containers = get_containers();

// 获取当前端口转发规则
$rules = get_port_forwarding_rules();
$running_containers = array_filter($containers, function($container) {
    return $container['status'] === 'running';
});

ob_start();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="fas fa-exchange-alt me-2"></i>端口转发管理</h2>
    <a href="index.php?action=containers" class="btn btn-outline-primary">
        <i class="fas fa-arrow-left me-1"></i>返回容器列表
    </a>
</div>

<?php if (!$CONFIG['port_forwarding']['enabled']): ?>
<div class="alert alert-warning">
    <i class="fas fa-exclamation-triangle me-2"></i>
    <strong>端口转发功能已禁用</strong> - 请在配置文件中启用此功能
</div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">添加端口转发规则</h5>
            </div>
            <div class="card-body">
                <form method="post" action="index.php?action=port_forwarding_action" id="addRuleForm">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="protocol" class="form-label">协议</label>
                                <select class="form-select" id="protocol" name="protocol" required>
                                    <option value="tcp">TCP</option>
                                    <option value="udp">UDP</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="external_port" class="form-label">外部端口</label>
                                <input type="number" class="form-control" id="external_port" name="external_port" 
                                       min="<?php echo $CONFIG['port_forwarding']['allowed_ports']['min']; ?>" 
                                       max="<?php echo $CONFIG['port_forwarding']['allowed_ports']['max']; ?>" 
                                       placeholder="1024-65535" required>
                                <div class="form-text">端口范围: <?php echo $CONFIG['port_forwarding']['allowed_ports']['min']; ?>-65535</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="container_name" class="form-label">目标容器</label>
                                <select class="form-select" id="container_name" name="container_name" required>
                                    <option value="">选择容器...</option>
                                    <?php foreach ($running_containers as $name => $container): ?>
                                        <option value="<?php echo htmlspecialchars($name); ?>">
                                            <?php echo htmlspecialchars($name); ?> (<?php echo htmlspecialchars($container['ip']); ?>)
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <div class="form-text">只显示运行中的容器</div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="internal_port" class="form-label">内部端口</label>
                                <input type="number" class="form-control" id="internal_port" name="internal_port" 
                                       min="1" max="65535" placeholder="1-65535" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="description" class="form-label">描述（可选）</label>
                        <input type="text" class="form-control" id="description" name="description" placeholder="规则描述">
                    </div>
                    
                    <button type="submit" class="btn btn-success w-100" <?php echo !$CONFIG['port_forwarding']['enabled'] ? 'disabled' : ''; ?>>
                        <i class="fas fa-plus me-1"></i>添加规则
                    </button>
                </form>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">使用说明</h5>
            </div>
            <div class="card-body">
                <h6>端口转发功能说明：</h6>
                <ul>
                    <li>端口转发允许将主服务器的外部端口流量转发到容器的内部端口</li>
                    <li>外部端口范围: <?php echo $CONFIG['port_forwarding']['allowed_ports']['min']; ?>-65535</li>
                    <li>内部端口范围: 1-65535</li>
                    <li>支持的协议: TCP、UDP</li>
                    <li>只有运行中的容器才能设置端口转发</li>
                </ul>
                
                <h6>示例：</h6>
                <p>将主服务器的TCP端口8080转发到web-server容器的80端口：</p>
                <code>TCP 8080 → web-server:80</code>
                
                <h6>注意事项：</h6>
                <ul>
                    <li>确保防火墙允许转发端口的流量</li>
                    <li>端口转发规则在重启后可能失效，需要配置持久化</li>
                    <li>如果容器IP发生变化，需要更新转发规则</li>
                    <li>避免使用系统保留端口（1-1023）</li>
                    <li>确保iptables服务正在运行</li>
                </ul>
                
                <h6>验证规则：</h6>
                <p>查看当前iptables规则：</p>
                <pre>sudo iptables -t nat -L PREROUTING -n --line-numbers</pre>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">端口转发规则 (<?php echo count($rules); ?> 条)</h5>
                <?php if (!empty($rules)): ?>
                    <button type="button" class="btn btn-outline-secondary btn-sm" onclick="refreshRules()">
                        <i class="fas fa-sync-alt me-1"></i>刷新
                    </button>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if (!empty($rules)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>协议</th>
                                    <th>外部端口</th>
                                    <th>目标容器</th>
                                    <th>内部端口</th>
                                    <th>操作</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($rules as $rule): ?>
                                    <tr>
                                        <td>
                                            <span class="badge bg-<?php echo $rule['protocol'] == 'tcp' ? 'primary' : 'info'; ?>">
                                                <?php echo strtoupper($rule['protocol']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <code class="bg-light p-1 rounded"><?php echo htmlspecialchars($rule['external_port']); ?></code>
                                        </td>
                                        <td>
                                            <div>
                                                <?php echo htmlspecialchars($rule['container_name']); ?>
                                                <?php if ($rule['container_ip'] != '未知'): ?>
                                                    <br><small class="text-muted"><?php echo htmlspecialchars($rule['container_ip']); ?></small>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <code class="bg-light p-1 rounded"><?php echo htmlspecialchars($rule['internal_port']); ?></code>
                                        </td>
                                        <td>
                                            <form method="post" action="index.php?action=port_forwarding_action" class="d-inline">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="rule_num" value="<?php echo htmlspecialchars($rule['rule_num']); ?>">
                                                <input type="hidden" name="protocol" value="<?php echo htmlspecialchars($rule['protocol']); ?>">
                                                <button type="submit" class="btn btn-danger btn-sm" 
                                                        onclick="return confirm('确定删除此端口转发规则吗？')" title="删除规则">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-exchange-alt fa-3x text-muted mb-3"></i>
                        <p class="text-muted">暂无端口转发规则</p>
                        <?php if ($CONFIG['port_forwarding']['enabled'] && !empty($running_containers)): ?>
                            <p class="text-muted">请添加第一条端口转发规则</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if (!empty($rules)): ?>
        <div class="card mt-4">
            <div class="card-header">
                <h5 class="card-title mb-0">规则统计</h5>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-4">
                        <div class="border rounded p-2">
                            <div class="h5 mb-0"><?php echo count($rules); ?></div>
                            <small class="text-muted">总规则数</small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="border rounded p-2">
                            <div class="h5 mb-0"><?php echo count(array_filter($rules, function($r) { return $r['protocol'] == 'tcp'; })); ?></div>
                            <small class="text-muted">TCP规则</small>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="border rounded p-2">
                            <div class="h5 mb-0"><?php echo count(array_filter($rules, function($r) { return $r['protocol'] == 'udp'; })); ?></div>
                            <small class="text-muted">UDP规则</small>
                        </div>
                    </div>
                </div>
                
                <div class="mt-3">
                    <h6>使用的端口：</h6>
                    <div class="d-flex flex-wrap gap-1">
                        <?php 
                        $used_ports = [];
                        foreach ($rules as $rule) {
                            $used_ports[] = $rule['external_port'] . '/' . $rule['protocol'];
                        }
                        $used_ports = array_unique($used_ports);
                        sort($used_ports);
                        ?>
                        <?php foreach ($used_ports as $port): ?>
                            <span class="badge bg-secondary"><?php echo $port; ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
function refreshRules() {
    window.location.reload();
}

// 表单验证
document.getElementById('addRuleForm').addEventListener('submit', function(e) {
    const externalPort = parseInt(document.getElementById('external_port').value);
    const internalPort = parseInt(document.getElementById('internal_port').value);
    const minPort = <?php echo $CONFIG['port_forwarding']['allowed_ports']['min']; ?>;
    const maxPort = 65535;
    
    if (externalPort < minPort || externalPort > maxPort) {
        e.preventDefault();
        alert('外部端口必须在' + minPort + '-' + maxPort + '范围内');
        return false;
    }
    
    if (internalPort < 1 || internalPort > 65535) {
        e.preventDefault();
        alert('内部端口必须在1-65535范围内');
        return false;
    }
    
    return true;
});

// 自动填充内部端口（当选择容器时）
document.getElementById('container_name').addEventListener('change', function() {
    const containerName = this.value;
    if (containerName) {
        // 根据容器名称猜测常用端口
        if (containerName.includes('web') || containerName.includes('http')) {
            document.getElementById('internal_port').value = '80';
        } else if (containerName.includes('mysql') || containerName.includes('db')) {
            document.getElementById('internal_port').value = '3306';
        } else if (containerName.includes('ssh')) {
            document.getElementById('internal_port').value = '22';
        } else if (containerName.includes('ftp')) {
            document.getElementById('internal_port').value = '21';
        }
    }
});
</script>
<?php
$content = ob_get_clean();
include 'templates/base.php';
?>