<?php
require_once './config.php';
require_once './functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    flash_message('非法请求', 'error');
    header('Location: index.php?action=containers');
    exit;
}

$action = $_POST['action'] ?? '';
$container_name = $_POST['container_name'] ?? '';

if (empty($container_name) || empty($action)) {
    flash_message('参数错误', 'error');
    header('Location: index.php?action=containers');
    exit;
}

if (!check_permission($action, $container_name)) {
    flash_message("没有权限执行 {$action} 操作", 'error');
    header('Location: index.php?action=containers');
    exit;
}

// 执行操作
if (in_array($action, ['start', 'stop', 'restart', 'freeze', 'unfreeze'])) {
    $result = execute_lxc_command("{$action} {$container_name}");
} elseif ($action === 'delete') {
    $result = execute_lxc_command("delete {$container_name} --force");
} else {
    flash_message('不支持的操作', 'error');
    header('Location: index.php?action=containers');
    exit;
}

if ($result['success']) {
    flash_message("操作执行成功: {$action} {$container_name}", 'success');
} else {
    $error_msg = !empty($result['error']) ? implode(' ', $result['error']) : '未知错误';
    flash_message("操作失败: {$error_msg}", 'error');
}

header('Location: index.php?action=containers');
exit;
?>