<?php
session_start();
session_destroy();
flash_message('已退出登录', 'info');
header('Location: index.php?action=login');
exit;
?>