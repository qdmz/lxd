<?php
require_once './config.php';
require_once './functions.php';

if (!check_permission('create_own')) {
    flash_message('没有权限创建容器', 'error');
    header('Location: index.php?action=containers');
    exit;
}

global $CONFIG;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $container_name = trim($_POST['container_name'] ?? '');
    $template = $_POST['template'] ?? '';
    $cpu_limit = trim($_POST['cpu_limit'] ?? '');
    $memory_limit = trim($_POST['memory_limit'] ?? '');
    
    if (empty($container_name)) {
        flash_message('请填写容器名称', 'error');
        header('Location: index.php?action=create');
        exit;
    }
    
    if (empty($template)) {
        flash_message('请选择模板', 'error');
        header('Location: index.php?action=create');
        exit;
    }
    
    // 生成最终的容器名称
    $final_name = generate_container_name($container_name);
    
    // 验证容器名称格式
    if (!preg_match('/^[a-z0-9\-_]+$/', $final_name)) {
        flash_message('容器名称只能包含小写字母、数字、横线和下划线', 'error');
        header('Location: index.php?action=create');
        exit;
    }
    
    // 检查容器是否已存在
    $existing_containers = get_containers();
    if (isset($existing_containers[$final_name])) {
        flash_message('容器已存在', 'error');
        header('Location: index.php?action=create');
        exit;
    }
    
    // 检查用户是否有权限创建此名称的容器
    if (!check_container_permission($final_name)) {
        flash_message('没有权限创建此名称的容器', 'error');
        header('Location: index.php?action=create');
        exit;
    }
    
    // 创建容器
    $result = execute_lxc_command("launch {$template} {$final_name}");
    
    if (!$result['success']) {
        $error_msg = !empty($result['error']) ? implode(' ', $result['error']) : '未知错误';
        flash_message("创建失败: {$error_msg}", 'error');
        header('Location: index.php?action=create');
        exit;
    }
    
    // 设置资源限制
    if (!empty($cpu_limit)) {
        execute_lxc_command("config set {$final_name} limits.cpu {$cpu_limit}");
    }
    
    if (!empty($memory_limit)) {
        execute_lxc_command("config set {$final_name} limits.memory {$memory_limit}");
    }
    
    flash_message("容器 {$final_name} 创建成功", 'success');
    header('Location: index.php?action=containers');
    exit;
}

$title = '创建容器 - LXC容器管理';
ob_start();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>创建新容器</h2>
    <a href="index.php?action=containers" class="btn btn-outline-primary">
        <i class="fas fa-arrow-left me-1"></i>返回容器列表
    </a>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">容器配置</h5>
    </div>
    <div class="card-body">
        <form method="post">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="container_name" class="form-label">容器名称</label>
                        <input type="text" class="form-control" id="container_name" name="container_name" 
                               pattern="[a-zA-Z0-9\-_]+" title="只能包含字母、数字、横线和下划线" required>
                        <div class="form-text">
                            <?php if ($_SESSION['user_role'] == 'admin'): ?>
                                请输入容器名称（只能包含字母、数字、横线和下划线）
                            <?php else: ?>
                                注意：容器名称将自动添加 "<?php echo $_SESSION['username']; ?>-" 前缀
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="template" class="form-label">模板</label>
                        <select class="form-control" id="template" name="template" required>
                            <option value="">选择模板...</option>
                            <?php foreach ($CONFIG['templates'] as $key => $value): ?>
                                <option value="<?php echo $value; ?>"><?php echo $key; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="cpu_limit" class="form-label">CPU限制 (核心数)</label>
                        <input type="text" class="form-control" id="cpu_limit" name="cpu_limit" 
                               value="<?php echo $CONFIG['default_limits']['cpu']; ?>" placeholder="例如: 1 或 1-3">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="memory_limit" class="form-label">内存限制</label>
                        <input type="text" class="form-control" id="memory_limit" name="memory_limit" 
                               value="<?php echo $CONFIG['default_limits']['memory']; ?>" placeholder="例如: 512MB 或 2GB">
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-success">
                <i class="fas fa-plus-circle me-1"></i>创建容器
            </button>
        </form>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="card-title mb-0">使用说明</h5>
    </div>
    <div class="card-body">
        <h6>容器创建说明：</h6>
        <ul>
            <li><strong>容器名称</strong>：只能包含小写字母、数字、横线和下划线</li>
            <li><strong>模板选择</strong>：选择适合的操作系统模板</li>
            <li><strong>资源限制</strong>：可设置CPU、内存和磁盘限制（可选）</li>
            <li><strong>权限说明</strong>：
                <?php if ($_SESSION['user_role'] == 'admin'): ?>
                    管理员可以创建任意名称的容器
                <?php else: ?>
                    普通用户创建的容器会自动添加用户名前缀（如：<?php echo $_SESSION['username']; ?>-容器名）
                <?php endif; ?>
            </li>
        </ul>
        
        <h6>可用模板：</h6>
        <div class="row">
            <?php foreach ($CONFIG['templates'] as $key => $value): ?>
                <div class="col-md-3">
                    <div class="card mb-2">
                        <div class="card-body py-2">
                            <strong><?php echo $key; ?></strong><br>
                            <small class="text-muted"><?php echo $value; ?></small>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
include 'templates/base.php';
?>