<?php
/**
 * LXC容器Web管理工具 - PHP版本
 * 基于Python版本功能重写
 */

session_start();

// 配置信息
$CONFIG = [
    // 用户配置
    'users' => [
        'admin' => [
            'password' => 'admin123',
            'role' => 'admin',
            'allowed_containers' => ['*']
        ],
        'user1' => [
            'password' => 'user123',
            'role' => 'user',
            'allowed_containers' => ['web-server', 'db-server', 'user1-']
        ],
        'user2' => [
            'password' => 'user123',
            'role' => 'user',
            'allowed_containers' => ['app-server', 'user2-']
        ],
        'viewer' => [
            'password' => 'view123',
            'role' => 'viewer',
            'allowed_containers' => ['web-server']
        ]
    ],
    
    // 权限定义
    'permissions' => [
        'admin' => ['view', 'start', 'stop', 'restart', 'freeze', 'create', 'delete', 'edit', 'backup', 'restore', 'monitor', 'manage_users', 'port_forwarding'],
        'user' => ['view', 'start', 'stop', 'restart', 'freeze', 'backup', 'monitor', 'create_own'],
        'viewer' => ['view', 'monitor']
    ],
    
    // LXC配置
    'lxc_path' => '/var/lib/lxc',
    'backup_path' => '/www/backups/lxc',
    'templates' => [
        'ubuntu' => 'ubuntu:22.04',
        'alpine' => 'alpine:edge',
        'centos' => 'centos:8',
        'debian' => 'debian:11'
    ],
    
    // 资源限制默认值
    'default_limits' => [
        'cpu' => '1',
        'memory' => '512MB',
        'disk' => '10GB'
    ],
    
    // LXC命令配置
    'lxc_command' => [
        'use_sudo' => false,
        'lxc_path' => '/snap/bin/lxc',
        'socket_path' => '/var/snap/lxd/common/lxd/unix.socket'
    ],
    
    // 端口转发配置
    'port_forwarding' => [
        'enabled' => true,
        'iptables_path' => '/sbin/iptables',
        'ip6tables_path' => '/sbin/ip6tables',
        'rules_file' => '/etc/iptables/rules.v4',
        'allowed_ports' => [
            'min' => 1024,
            'max' => 65535
        ]
    ]
];

// 工具函数
function execute_command($command, $shell = false) {
    $output = [];
    $return_code = 0;
    
    if ($shell) {
        exec($command, $output, $return_code);
    } else {
        exec(escapeshellcmd($command), $output, $return_code);
    }
    
    return [
        'success' => $return_code === 0,
        'output' => $output,
        'error' => $return_code !== 0 ? ['Command failed with return code: ' . $return_code] : [],
        'returncode' => $return_code
    ];
}

function execute_lxc_command($command) {
    global $CONFIG;
    $lxc_config = $CONFIG['lxc_command'];
    $lxc_path = $lxc_config['lxc_path'];
    
    if ($lxc_config['use_sudo']) {
        $full_command = "sudo -n {$lxc_path} {$command}";
    } else {
        $full_command = "{$lxc_path} {$command}";
    }
    
    return execute_command($full_command);
}

function execute_sudo_command($command) {
    $full_command = "sudo {$command}";
    return execute_command($full_command, true);
}

function check_permission($action, $container_name = null) {
    if (!isset($_SESSION['user_role'])) {
        return false;
    }
    
    global $CONFIG;
    $role = $_SESSION['user_role'];
    
    // 管理员拥有所有权限
    if ($role === 'admin') {
        return true;
    }
    
    // 检查角色是否存在权限配置
    if (!isset($CONFIG['permissions'][$role])) {
        return false;
    }
    
    // 检查基本权限
    if (!in_array($action, $CONFIG['permissions'][$role])) {
        return false;
    }
    
    // 如果涉及具体容器，检查容器权限
    if ($container_name !== null && !check_container_permission($container_name)) {
        return false;
    }
    
    return true;
}

function check_container_permission($container_name) {
    if ($_SESSION['user_role'] === 'admin') {
        return true;
    }
    
    $allowed_containers = $_SESSION['allowed_containers'] ?? [];
    
    foreach ($allowed_containers as $pattern) {
        // 如果模式以-结尾，表示前缀匹配
        if (substr($pattern, -1) === '-') {
            $prefix = substr($pattern, 0, -1);
            if (strpos($container_name, $prefix) === 0) {
                return true;
            }
        } elseif ($pattern === $container_name || $pattern === '*') {
            return true;
        }
    }
    
    return false;
}

function filter_containers_by_permission($containers) {
    return array_filter($containers, function($container) {
        return check_container_permission($container['name']);
    }, ARRAY_FILTER_USE_BOTH);
}

function generate_container_name($base_name) {
    if ($_SESSION['user_role'] === 'admin') {
        return $base_name;
    }
    
    $username = $_SESSION['username'] ?? '';
    
    // 如果已经以用户名开头，则不重复添加
    if (strpos($base_name, "{$username}-") === 0) {
        return $base_name;
    }
    
    return "{$username}-{$base_name}";
}

function login_required() {
    if (!isset($_SESSION['username'])) {
        header('Location: login.php');
        exit;
    }
}

function get_containers() {
    $result = execute_lxc_command("list --format json");
    $containers = [];
    
    if ($result['success'] && !empty($result['output'])) {
        $json_output = implode('', $result['output']);
        $containers_data = json_decode($json_output, true);
        
        if (json_last_error() === JSON_ERROR_NONE) {
            foreach ($containers_data as $container_data) {
                $name = $container_data['name'] ?? '未知';
                $status = strtolower($container_data['status'] ?? 'unknown');
                $ip = '未知';
                
                // 安全地获取IP地址
                if (isset($container_data['state']) && is_array($container_data['state'])) {
                    $state = $container_data['state'];
                    if (isset($state['network']) && is_array($state['network'])) {
                        foreach ($state['network'] as $interface => $net_info) {
                            if (is_array($net_info) && isset($net_info['addresses']) && is_array($net_info['addresses'])) {
                                foreach ($net_info['addresses'] as $addr) {
                                    if (is_array($addr) && 
                                        ($addr['family'] ?? '') === 'inet' && 
                                        ($addr['scope'] ?? '') === 'global') {
                                        $ip = $addr['address'] ?? '未知';
                                        break 2;
                                    }
                                }
                            }
                        }
                    }
                }
                
                $containers[$name] = [
                    'name' => $name,
                    'status' => $status,
                    'ip' => $ip,
                    'cpu_usage' => '0%',
                    'memory_usage' => '0MB/0MB',
                    'disk_usage' => '0GB/0GB',
                    'processes' => '0',
                    'owner' => '未知'
                ];
                
                // 尝试获取容器所有者
                if (strpos($name, '-') !== false) {
                    $prefix = explode('-', $name)[0];
                    $containers[$name]['owner'] = $prefix;
                }
            }
        } else {
            // JSON解析失败，尝试解析文本格式
            $result = execute_lxc_command("list");
            if ($result['success']) {
                foreach ($result['output'] as $line) {
                    if (strpos($line, 'NAME') !== false || strpos($line, '---') !== false || trim($line) === '') {
                        continue;
                    }
                    
                    $parts = preg_split('/\s+/', $line);
                    if (count($parts) >= 2) {
                        $name = $parts[0];
                        $status = strtolower($parts[1]);
                        $ip = '未知';
                        
                        // 尝试从后续部分提取IP
                        for ($i = 2; $i < count($parts); $i++) {
                            if (strpos($parts[$i], '.') !== false && substr_count($parts[$i], '.') === 3) {
                                $ip_parts = explode('.', $parts[$i]);
                                if (count($ip_parts) === 4 && 
                                    ctype_digit(implode('', $ip_parts))) {
                                    $ip = $parts[$i];
                                    break;
                                }
                            }
                        }
                        
                        $containers[$name] = [
                            'name' => $name,
                            'status' => $status,
                            'ip' => $ip,
                            'cpu_usage' => '0%',
                            'memory_usage' => '0MB/0MB',
                            'disk_usage' => '0GB/0GB',
                            'processes' => '0',
                            'owner' => '未知'
                        ];
                        
                        if (strpos($name, '-') !== false) {
                            $prefix = explode('-', $name)[0];
                            $containers[$name]['owner'] = $prefix;
                        }
                    }
                }
            }
        }
    }
    
    return filter_containers_by_permission($containers);
}

function get_backups() {
    global $CONFIG;
    $backup_dir = $CONFIG['backup_path'];
    $backups = [];
    
    if (!is_dir($backup_dir)) {
        return $backups;
    }
    
    try {
        $files = scandir($backup_dir);
        foreach ($files as $file) {
            if (strpos($file, '.tar.gz') !== false && strpos($file, '_backup_') !== false) {
                $parts = explode('_backup_', $file);
                if (count($parts) === 2) {
                    $container_name = $parts[0];
                    $timestamp = str_replace('.tar.gz', '', $parts[1]);
                    
                    if (check_container_permission($container_name)) {
                        $file_path = $backup_dir . '/' . $file;
                        $file_size = file_exists($file_path) ? filesize($file_path) : 0;
                        
                        $backups[] = [
                            'file' => $file,
                            'container' => $container_name,
                            'date' => str_replace('_', ' ', $timestamp),
                            'path' => $file_path,
                            'size' => $file_size
                        ];
                    }
                }
            }
        }
    } catch (Exception $e) {
        error_log("Error reading backups: " . $e->getMessage());
    }
    
    return $backups;
}

function flash_message($message, $type = 'info') {
    if (!isset($_SESSION['flash_messages'])) {
        $_SESSION['flash_messages'] = [];
    }
    $_SESSION['flash_messages'][] = ['message' => $message, 'type' => $type];
}

function get_flash_messages() {
    if (isset($_SESSION['flash_messages'])) {
        $messages = $_SESSION['flash_messages'];
        unset($_SESSION['flash_messages']);
        return $messages;
    }
    return [];
}

// 创建必要的目录
if (!is_dir($CONFIG['backup_path'])) {
    mkdir($CONFIG['backup_path'], 0755, true);
}

// 路由处理
$action = $_GET['action'] ?? 'index';

switch ($action) {
    case 'login':
        include 'templates/login.php';
        break;
    case 'logout':
        include 'controllers/logout.php';
        break;
    case 'containers':
        login_required();
        include 'controllers/containers.php';
        break;
    case 'monitor':
        login_required();
        include 'controllers/monitor.php';
        break;
    case 'create':
        login_required();
        include 'controllers/create.php';
        break;
    case 'backup':
        login_required();
        include 'controllers/backup.php';
        break;
    case 'port_forwarding':
        login_required();
        include 'controllers/port_forwarding.php';
        break;
    case 'system_status':
        login_required();
        include 'controllers/system_status.php';
        break;
    default:
        if (isset($_SESSION['username'])) {
            header('Location: ?action=containers');
        } else {
            header('Location: ?action=login');
        }
        exit;
}
?>