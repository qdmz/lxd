<?php
/**
 * LXC容器Web管理工具 - PHP版本
 * 主入口文件
 */

session_start();

// 包含配置文件
require_once 'config.php';
// 包含工具函数
require_once 'functions.php';

// 路由处理
$action = $_GET['action'] ?? 'index';

switch ($action) {
    case 'login':
        include 'controllers/login.php';
        break;
    case 'logout':
        include 'controllers/logout.php';
        break;
    case 'containers':
        login_required();
        include 'controllers/containers.php';
        break;
    case 'monitor':
        login_required();
        include 'controllers/monitor.php';
        break;
    case 'create':
        login_required();
        include 'controllers/create.php';
        break;
    case 'backup':
        login_required();
        include 'controllers/backup.php';
        break;
    case 'port_forwarding':
        login_required();
        include 'controllers/port_forwarding.php';
        break;
    case 'system_status':
        login_required();
        include 'controllers/system_status.php';
        break;
    case 'container_action':
        login_required();
        include 'controllers/container_action.php';
        break;
    case 'backup_action':
        login_required();
        include 'controllers/backup_action.php';
        break;
    case 'port_forwarding_action':
        login_required();
        include 'controllers/port_forwarding_action.php';
        break;
    default:
        if (isset($_SESSION['username'])) {
            header('Location: index.php?action=containers');
        } else {
            header('Location: index.php?action=login');
        }
        exit;
}
?>