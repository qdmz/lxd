<?php
$title = '系统状态检查 - LXC容器管理';
ob_start();
?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><i class="fas fa-server me-2"></i>系统状态检查</h2>
    <a href="index.php?action=containers" class="btn btn-outline-primary">
        <i class="fas fa-arrow-left me-1"></i>返回容器列表
    </a>
</div>

<div class="row">
    <!-- 系统概览 -->
    <div class="col-md-12">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">系统概览</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3">
                        <div class="text-center">
                            <div class="stat-number"><?php echo $container_stats['total']; ?></div>
                            <div class="stat-label">总容器数</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="text-center">
                            <div class="stat-number text-success"><?php echo $container_stats['running']; ?></div>
                            <div class="stat-label">运行中</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="text-center">
                            <div class="stat-number text-warning"><?php echo $container_stats['stopped']; ?></div>
                            <div class="stat-label">已停止</div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="text-center">
                            <div class="stat-number text-danger"><?php echo $container_stats['error']; ?></div>
                            <div class="stat-label">错误状态</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <!-- LXD服务状态 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">LXD服务状态</h5>
            </div>
            <div class="card-body">
                <?php if ($lxd_service_status['success'] && $lxd_service_status['output'][0] === 'active'): ?>
                    <div class="alert alert-success">
                        <span class="service-status service-active"></span>
                        <strong>LXD服务运行正常</strong>
                        <?php if ($lxd_version['success'] && !empty($lxd_version['output'])): ?>
                            <br><small>版本: <?php echo $lxd_version['output'][0]; ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($lxd_service_info['success'] && !empty($lxd_service_info['output'])): ?>
                        <h6>服务状态详情:</h6>
                        <div class="command-output">
                            <?php foreach ($lxd_service_info['output'] as $line): ?>
                                <?php echo htmlspecialchars($line); ?><br>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="alert alert-danger">
                        <span class="service-status service-inactive"></span>
                        <strong>LXD服务未运行</strong>
                    </div>
                    <p>LXD服务可能未启动或配置不正确。请检查:</p>
                    <ul>
                        <li>LXD服务状态: <code>sudo systemctl status snap.lxd.daemon</code></li>
                        <li>启动LXD服务: <code>sudo systemctl start snap.lxd.daemon</code></li>
                        <li>初始化LXD: <code>sudo lxd init</code></li>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <!-- 存储池状态 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">存储池 (<?php echo count($storage_pools); ?> 个)</h5>
            </div>
            <div class="card-body">
                <?php if (!empty($storage_pools)): ?>
                    <?php foreach ($storage_pools as $pool): ?>
                        <div class="mb-3 p-3 border rounded">
                            <h6 class="mb-2"><?php echo htmlspecialchars($pool['name']); ?></h6>
                            <div class="row">
                                <div class="col-6">
                                    <small class="text-muted">驱动: <?php echo htmlspecialchars($pool['driver']); ?></small>
                                </div>
                                <div class="col-6 text-end">
                                    <small class="text-muted">已使用: <?php echo count($pool['used_by']); ?> 个容器</small>
                                </div>
                            </div>
                            <?php if (!empty($pool['config'])): ?>
                                <div class="mt-2">
                                    <small class="text-muted">配置:</small>
                                    <?php foreach ($pool['config'] as $key => $value): ?>
                                        <br><small><?php echo htmlspecialchars($key); ?>: <?php echo htmlspecialchars($value); ?></small>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>未找到存储池
                    </div>
                    <p>这可能是因为LXD未正确初始化。请尝试:</p>
                    <ol>
                        <li>运行 <code>sudo lxd init</code> 命令初始化LXD</li>
                        <li>创建默认存储池: <code>lxc storage create default dir</code></li>
                    </ol>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <!-- 网络配置 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">网络配置 (<?php echo count($networks); ?> 个)</h5>
            </div>
            <div class="card-body">
                <?php if (!empty($networks)): ?>
                    <?php foreach ($networks as $network): ?>
                        <div class="mb-3 p-3 border rounded">
                            <h6 class="mb-2"><?php echo htmlspecialchars($network['name']); ?></h6>
                            <div class="row">
                                <div class="col-6">
                                    <small class="text-muted">类型: <?php echo htmlspecialchars($network['type']); ?></small>
                                </div>
                                <div class="col-6 text-end">
                                    <?php if ($network['managed']): ?>
                                        <span class="badge bg-success">托管</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">非托管</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php if (!empty($network['config'])): ?>
                                <div class="mt-2">
                                    <small class="text-muted">配置:</small>
                                    <?php foreach ($network['config'] as $key => $value): ?>
                                        <br><small><?php echo htmlspecialchars($key); ?>: <?php echo htmlspecialchars($value); ?></small>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>未找到网络配置
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- 系统信息 -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">系统信息</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-6">
                        <strong>主机名:</strong><br>
                        <?php echo htmlspecialchars($system_info['hostname']); ?>
                    </div>
                    <div class="col-6">
                        <strong>运行时间:</strong><br>
                        <?php echo htmlspecialchars($system_info['uptime']); ?>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-12">
                        <strong>负载平均值:</strong><br>
                        <?php echo htmlspecialchars($system_info['load_average']); ?>
                    </div>
                </div>
                
                <?php if (!empty($system_info['memory_usage'])): ?>
                    <div class="mt-3">
                        <strong>内存使用:</strong>
                        <div class="command-output">
                            <?php foreach ($system_info['memory_usage'] as $line): ?>
                                <?php echo htmlspecialchars($line); ?><br>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($system_info['disk_usage'])): ?>
                    <div class="mt-3">
                        <strong>磁盘使用:</strong>
                        <div class="command-output">
                            <?php foreach ($system_info['disk_usage'] as $line): ?>
                                <?php echo htmlspecialchars($line); ?><br>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- 服务状态 -->
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">服务状态</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>服务</th>
                            <th>状态</th>
                            <th>描述</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>LXD</td>
                            <td>
                                <?php if ($services_status['lxd']['success'] && $services_status['lxd']['output'][0] === 'active'): ?>
                                    <span class="service-status service-active"></span>运行中
                                <?php else: ?>
                                    <span class="service-status service-inactive"></span>停止
                                <?php endif; ?>
                            </td>
                            <td>容器管理服务</td>
                        </tr>
                        <tr>
                            <td>AppArmor</td>
                            <td>
                                <?php if ($services_status['apparmor']['success'] && $services_status['apparmor']['output'][0] === 'active'): ?>
                                    <span class="service-status service-active"></span>运行中
                                <?php else: ?>
                                    <span class="service-status service-inactive"></span>停止
                                <?php endif; ?>
                            </td>
                            <td>安全模块</td>
                        </tr>
                        <tr>
                            <td>UFW</td>
                            <td>
                                <?php if ($services_status['ufw']['success'] && $services_status['ufw']['output'][0] === 'active'): ?>
                                    <span class="service-status service-active"></span>运行中
                                <?php else: ?>
                                    <span class="service-status service-inactive"></span>停止
                                <?php endif; ?>
                            </td>
                            <td>防火墙</td>
                        </tr>
                        <tr>
                            <td>iptables</td>
                            <td>
                                <?php if ($services_status['iptables']['success'] && $services_status['iptables']['output'][0] === 'active'): ?>
                                    <span class="service-status service-active"></span>运行中
                                <?php else: ?>
                                    <span class="service-status service-inactive"></span>停止
                                <?php endif; ?>
                            </td>
                            <td>防火墙规则</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- 备份状态 -->
    <div class="col-md-6">
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">备份状态</h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <strong>备份目录:</strong> <?php echo htmlspecialchars($CONFIG['backup_path']); ?>
                </div>
                <div class="mb-3">
                    <strong>状态:</strong>
                    <?php if ($backup_status['exists']): ?>
                        <?php if ($backup_status['writable']): ?>
                            <span class="badge bg-success">可读写</span>
                        <?php else: ?>
                            <span class="badge bg-warning">只读</span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="badge bg-danger">不存在</span>
                    <?php endif; ?>
                </div>
                <div class="mb-3">
                    <strong>备份大小:</strong>
                    <?php if ($backup_status['size'] > 0): ?>
                        <?php echo number_format($backup_status['size'] / 1024 / 1024, 2); ?> MB
                    <?php else: ?>
                        0 MB
                    <?php endif; ?>
                </div>
                <?php if (!$backup_status['exists']): ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle me-2"></i>备份目录不存在，将自动创建
                    </div>
                <?php elseif (!$backup_status['writable']): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i>备份目录不可写，请检查权限
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- 故障排除 -->
<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">故障排除</h5>
    </div>
    <div class="card-body">
        <h6>常见问题解决方案：</h6>
        <ol>
            <li><strong>LXD服务未运行</strong>：
                <p>运行以下命令启动LXD服务：</p>
                <pre>sudo systemctl start snap.lxd.daemon
sudo systemctl enable snap.lxd.daemon</pre>
            </li>
            <li><strong>LXD未初始化</strong>：
                <p>运行以下命令初始化LXD：</p>
                <pre>sudo lxd init --auto</pre>
            </li>
            <li><strong>缺少存储池</strong>：
                <p>运行以下命令创建默认存储池：</p>
                <pre>lxc storage create default dir
lxc profile device add default root disk path=/ pool=default</pre>
            </li>
            <li><strong>权限问题</strong>：
                <p>确保Web服务器用户在lxd组中：</p>
                <pre>sudo usermod -a -G lxd www-data
sudo systemctl restart apache2</pre>
            </li>
        </ol>
        
        <div class="text-center mt-4">
            <a href="index.php?action=containers" class="btn btn-outline-primary">
                <i class="fas fa-arrow-left me-1"></i>返回容器列表
            </a>
        </div>
    </div>
</div>
<?php
$content = ob_get_clean();
include 'templates/base.php';
?>