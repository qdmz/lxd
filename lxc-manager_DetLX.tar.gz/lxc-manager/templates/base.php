<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($title) ? $title : 'LXC容器管理'; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #3498db;
            --success: #2ecc71;
            --warning: #f39c12;
            --danger: #e74c3c;
            --dark: #2c3e50;
            --light: #ecf0f1;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: var(--dark);
        }
        
        .navbar-brand {
            font-weight: 600;
        }
        
        .user-badge {
            background: var(--primary);
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
        }
        
        .status {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-running {
            background: #d4edda;
            color: #155724;
        }
        
        .status-stopped {
            background: #f8d7da;
            color: #721c24;
        }
        
        .status-frozen {
            background: #fff3cd;
            color: #856404;
        }
        
        .owner-tag {
            background: #e8f4fd;
            color: var(--primary);
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 12px;
            margin-left: 5px;
        }
        
        .resource-bar {
            background: #e0e0e0;
            border-radius: 10px;
            height: 10px;
            margin: 5px 0;
            overflow: hidden;
        }
        
        .resource-fill {
            height: 100%;
            border-radius: 10px;
        }
        
        .cpu-fill {
            background: var(--primary);
        }
        
        .memory-fill {
            background: var(--success);
        }
        
        .disk-fill {
            background: var(--warning);
        }
        
        .nav-link.active {
            font-weight: 600;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
        }
        
        .command-output {
            background: #2c3e50;
            color: #ecf0f1;
            padding: 10px;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
            max-height: 200px;
            overflow-y: auto;
        }
    </style>
    <?php if (isset($styles)): ?>
    <style><?php echo $styles; ?></style>
    <?php endif; ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php?action=containers">
                <i class="fas fa-server me-2"></i>LXC容器管理
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=containers">
                            <i class="fas fa-list me-1"></i>容器管理
                        </a>
                    </li>
                    
                    <?php if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'user', 'viewer'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=monitor">
                            <i class="fas fa-chart-bar me-1"></i>资源监控
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'user'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=create">
                            <i class="fas fa-plus-circle me-1"></i>创建容器
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'user'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=backup">
                            <i class="fas fa-archive me-1"></i>备份管理
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=port_forwarding">
                            <i class="fas fa-exchange-alt me-1"></i>端口转发
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'user', 'viewer'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="index.php?action=system_status">
                            <i class="fas fa-server me-1"></i>系统状态
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
                
                <ul class="navbar-nav">
                    <?php if (isset($_SESSION['username'])): ?>
                        <li class="nav-item">
                            <span class="navbar-text user-badge me-3">
                                <i class="fas fa-user me-1"></i>
                                <?php echo $_SESSION['username']; ?> (<?php echo $_SESSION['user_role']; ?>)
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?action=logout">
                                <i class="fas fa-sign-out-alt me-1"></i>退出
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="index.php?action=login">登录</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- 消息闪现 -->
        <?php
        $messages = get_flash_messages();
        foreach ($messages as $msg): ?>
            <div class="alert alert-<?php echo $msg['type'] == 'error' ? 'danger' : $msg['type']; ?> alert-dismissible fade show" role="alert">
                <i class="fas fa-<?php 
                    echo $msg['type'] == 'error' ? 'exclamation-triangle' : 
                         ($msg['type'] == 'success' ? 'check-circle' : 'info-circle'); 
                ?> me-2"></i>
                <?php echo $msg['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endforeach; ?>

        <?php echo $content; ?>
    </div>

    <footer class="bg-dark text-light mt-5 py-4">
        <div class="container text-center">
            <p class="mb-0">LXC容器Web管理工具 &copy; 2023</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 当前页面高亮
        document.addEventListener('DOMContentLoaded', function() {
            var currentUrl = window.location.search;
            var navLinks = document.querySelectorAll('.navbar-nav .nav-link');
            
            navLinks.forEach(function(link) {
                if (link.getAttribute('href') === currentUrl) {
                    link.classList.add('active');
                }
            });
        });
    </script>
    <?php if (isset($scripts)): ?>
    <script><?php echo $scripts; ?></script>
    <?php endif; ?>
</body>
</html>