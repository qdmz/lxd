<?php
global $CONFIG;
$title = '创建容器 - LXC容器管理';
ob_start();
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>创建新容器</h2>
    <a href="?action=containers" class="btn btn-outline-primary">
        <i class="fas fa-arrow-left me-1"></i>返回容器列表
    </a>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">容器配置</h5>
    </div>
    <div class="card-body">
        <form method="post">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="container_name" class="form-label">容器名称</label>
                        <input type="text" class="form-control" id="container_name" name="container_name" 
                               pattern="[a-zA-Z0-9\-_]+" title="只能包含字母、数字、横线和下划线" required>
                        <div class="form-text">
                            <?php if ($_SESSION['user_role'] === 'user'): ?>
                                注意：容器名称将自动添加 "<?php echo $_SESSION['username']; ?>-" 前缀
                            <?php else: ?>
                                请输入容器名称（只能包含字母、数字、横线和下划线）
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="template" class="form-label">模板</label>
                        <select class="form-control" id="template" name="template" required>
                            <option value="">选择模板...</option>
                            <?php foreach ($CONFIG['templates'] as $key => $value): ?>
                                <option value="<?php echo $value; ?>"><?php echo $key; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="cpu_limit" class="form-label">CPU限制 (核心数)</label>
                        <input type="text" class="form-control" id="cpu_limit" name="cpu_limit" 
                               value="<?php echo $CONFIG['default_limits']['cpu']; ?>" placeholder="例如: 1 或 1-3">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="memory_limit" class="form-label">内存限制</label>
                        <input type="text" class="form-control" id="memory_limit" name="memory_limit" 
                               value="<?php echo $CONFIG['default_limits']['memory']; ?>" placeholder="例如: 512MB 或 2GB">
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn btn-success">
                <i class="fas fa-plus-circle me-1"></i>创建容器
            </button>
        </form>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="card-title mb-0">使用说明</h5>
    </div>
    <div class="card-body">
        <h6>容器创建说明：</h6>
        <ul>
            <li><strong>容器名称</strong>：只能包含小写字母、数字、横线和下划线</li>
            <li><strong>模板选择</strong>：选择适合的操作系统模板</li>
            <li><strong>资源限制</strong>：可设置CPU、内存和磁盘限制（可选）</li>
            <li><strong>权限说明</strong>：
                <?php if ($_SESSION['user_role'] === 'admin'): ?>
                    管理员可以创建任意名称的容器
                <?php else: ?>
                    普通用户创建的容器会自动添加用户名前缀（如：<?php echo $_SESSION['username']; ?>-容器名）
                <?php endif; ?>
            </li>
        </ul>
        
        <h6>可用模板：</h6>
        <div class="row">
            <?php foreach ($CONFIG['templates'] as $key => $value): ?>
                <div class="col-md-3">
                    <div class="card mb-2">
                        <div class="card-body py-2">
                            <strong><?php echo $key; ?></strong><br>
                            <small class="text-muted"><?php echo $value; ?></small>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<?php
$content = ob_get_clean();
include 'base.php';
?>